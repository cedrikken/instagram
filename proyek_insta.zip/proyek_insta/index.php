<?php
session_start();

if(!isset($_SESSION['login'])) {
    header("location:login.php?pesan=logindulu");
}

include "koneksi.php";
$sql = "SELECT * FROM post ORDER BY no DESC";
$query = mysqli_query($koneksi, $sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css" integrity="sha512-5A8nwdMOWrSz20fDsjczgUidUBR8liPYU+WymTZP1lmY9G6Oc7HlZv156XqnsgNUzTyMefFTcsFH/tnJE/+xBg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="shortcut icon" href="gambar/logo.png">
    <title>playgram</title>
    <style>
      body{
      margin: 0;
      padding: 0;
      background: url() no-repeat;
      
      font-family: sans-serif;
      background-size: cover;
      background-repeat: no-repeat ;
      background-attachment: fixed;
      background-position: center;
    }
      .zoom{
        overflow: hidden;
        margin: 0 auto;
      }
      .zoom img {
        width: 100%;
        transition: 0.2s all ease-in-out;
      }
      .zoom:hover img {
        transform: scale(1.2);
        cursor: pointer;
      }
    </style>
</head>
<nav class="sticky-top navbar navbar-expand-lg bg-dark" data-bs-theme="dark">
  <div class="container-fluid">
  <div class="logo">
      <a class="navbar-light" href="#">
      <img src="gambar/playgram.png" width="200" height="60" class="d-inline-block" alt=""> </a>
      </div>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarColor01" aria-controls="navbarColor01" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
      
    <span><a class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal"><i class="fa fa-plus" ></i></a>
    <a class="btn btn-danger" href="logout.php"><i class="fa fa-sign-out" ></i></a>  
    </span> 
      
    </div>
  </div>
</nav>
<body style="background-color: grey;"> 
<section id="header">
 <center>
     <?php while ($post = mysqli_fetch_assoc($query)) { ?>   
        <div class="card mt-5 mb-5" style="width: 30rem;">
        <div class="card-body">  
          <div class="zoom">
        
        <tr>
        <center>
        <th></th>
        <td><img class="card-img-top" src="images/<?= $post['foto'] ?>" 
        alt="" width="80" height="300"></td>
        </div>
        <ul class="list-group list-group-flush">
        <li class="list-group-item">
        <th></th>
        <td><?=$post['caption']?></td>  
        </li>
        <li class="list-group-item">
        <th></th>
        <td><?=$post['lokasi']?></td> 
        </li>
         
        <li class="list-group-item">
    
     

    <td>
    <a class="btn btn-warning"data-bs-toggle="modal" data-bs-target="#editModal<?=$post['no']?>"><i class="fa fa-pencil"></i></a>
    <a class="btn btn-danger"href="hapus.php?no=<?= $post['no'] ?>"><i class="fa fa-trash-o"></i></a>
    </td>
    </tr>      
 </div>
 </div> 
 


<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel"></h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <form action="proses_tambah.php" method="post" enctype="multipart/form-data">
        
        <label for="" class="form-label">foto</label><br>
        <input class="form-control" type="file" name="foto" id="" required><br><br>

        <label for="" class="form-label">Caption</label><br>
        <input class="form-control" type="text" name="caption" id="" autocomplete="off"><br>

        <label for="" class="form-label">Lokasi</label><br>
        <input class="form-control" type="text" name="lokasi" id="" autocomplete="off"><br><br>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          <input type="submit" name="simpan"class="btn btn-primary"></button>
        </div>
    </form>
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="editModal<?=$post['no']?>" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="editModalLabel"></h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <form action="proses_edit.php" method="post" enctype="multipart/form-data">
        
      <input type="hidden" name="no" value="<?= $post['no'] ?>">
        <input type="hidden" name="foto_lama" value="<?= $post['foto'] ?>">

        <label for="">foto</label><br>
        <input type="file" name="foto" id="" value="<?= $post['foto'] ?>" ><br><br>
        <img src="images/<?= $post['foto'] ?>" width="340" height="250" alt="" ><br><br>
        
        <label for="">Caption</label>
        <input  class="form-control" type="text" name="caption" id="" value="<?= $post['caption'] ?>" autocomplete="off"><br>

        <label for="">Lokasi</label>
        <input class="form-control" type="text" name="lokasi" id="" value="<?= $post['lokasi'] ?>" autocomplete="off"><br>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary" name="ubah">Simpan</button>
        </div>
    </form>
      </div>
    </div>
  </div>
</div>
<?php } ?>
</div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body>
</html>